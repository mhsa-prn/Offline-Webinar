<?php $__env->startSection('content'); ?>
    <h3 class="my-3">وبینارهای ثبت نام شده</h3>
    <div class="row row-cols-1 row-cols-md-3 mb-3 text-center mt-3">
        <?php if(collect($webinars)->count() > 0): ?>
            <?php $__currentLoopData = $webinars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $webinar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col">
                <div class="card mb-4 rounded-3 shadow-sm">
                    <div class="card-header py-3">
                        <h4 class="my-0 fw-normal"><?php echo e($webinar->title); ?></h4>
                    </div>
                    <div class="card-body">
                        <h1 class="card-title pricing-card-title">
                            <?php if($webinar->price == 0): ?>
                                <h4 class="text-success">رایگان</h4>
                            <?php else: ?>
                                <h4 class="text-danger"><?php echo e($webinar->price); ?> تومان</h4>
                            <?php endif; ?>
                        </h1>
                        <img height="100px" width="100%" class="mb-3" src="/storage/images/<?php echo e($webinar->img); ?>">
                        <h6>ارائه دهنده: <?php echo e($webinar->user->name); ?> </h6>

                        <h6>دسته بندی: <?php echo e($webinar->category->name); ?> </h6>

                        <h6>تاریخ انتشار: <?php echo e(jdate($webinar->created_at)->format('d-m-Y')); ?> </h6>
                        <a href="<?php echo e(route('webinars.show',$webinar->id)); ?>" type="button" class="w-100 btn btn-lg
                    btn-outline-primary">مشاهده</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <div class="alert alert-danger"> شما در وبیناری ثبت نام نکردید</div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\webinar\resources\views/home.blade.php ENDPATH**/ ?>