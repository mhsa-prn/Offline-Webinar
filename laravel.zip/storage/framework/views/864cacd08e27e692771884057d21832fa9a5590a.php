<?php $__env->startSection('title'); ?>
    لیست دسته بندی ها
    <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h3 class="my-3">لیست دسته بندی ها</h3>
<a class="btn btn-primary btn-sm float-end" href="<?php echo e(route('admin.categories.create')); ?>">افزودن دسته بندی</a>
<div class="row">
    <div class="col mb-3">
        <form action="<?php echo e(route('admin.categories.index')); ?>" method="get">
            <div class="form-group">
                <div class="row">
                    <div class="col-9">
                        <input type="text" class="form-control" name="search" placeholder="جستجو">
                    </div>
                    <div class="col-2">
                        <button type="submit" class="btn btn-primary"> فیلتر</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<div class="row">
    <div class="col">
        <?php if(session()->has('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>
    </div>
</div>
    <div class="row">
        <div class="col">
            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                    <thead>
                    <tr>
                        <th>ردیف</th>
                        <th>نام</th>
                        <th>نام والد</th>
                        <th>عملیات</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td> <?php echo e($loop->index + 1); ?></td>
                            <td> <?php echo e($category->name); ?></td>
                            <td> <?php echo e($category->parent() ?
                                        $category->parent()->name : null); ?></td>

                            <td>
                                <form id="form-<?php echo e($category->id); ?>-delete" action="<?php echo e(route('admin.categories.destroy', $category->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                </form>
                                <a href="#" onclick="event.preventDefault();askForDelete(<?php echo e($category->id); ?>)" class="btn btn-sm btn-danger">حذف</a>
                                <a href="<?php echo e(route('admin.categories.edit',$category->id)); ?>" class="btn btn-sm btn-primary">ویرایش</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php echo e($categories->appends(['search'=>request()->search])); ?>

        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        function askForDelete(id){
            Swal.fire({
                title: '',
                text: "آیا از حذف دسته بندی اطمینان دارید؟",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'بله',
                cancelButtonText: 'خیر' ,
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById(`form-${id}-delete`).submit();

                }
            })
        }


    </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\webinar\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>