<div class="pricing-header p-3 pb-md-4 mx-auto text-center">
    <h1 class="display-4 fw-normal text-body-emphasis">وبینار دات آی آر</h1>
    <p class="fs-5 text-body-secondary" style="text-align: center">
        وبینار دات آی آر پلتفرمی در حوزه تکنولوژی می باشد که بطور تخصصی به برگزاری دوره های برنامه نویسی و هوش
        مصنوعی می پردازد. شما در این پلتفرم هم می توانید آموزش ببینید و هم آموزش دهید.
    </p>
</div>
<?php /**PATH C:\wamp64\www\webinar\resources\views/site-title.blade.php ENDPATH**/ ?>