<?php $__env->startSection('title'); ?>
    لیست وبینارها
    <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h3 class="my-3">لیست وبینارها</h3>
<a class="btn btn-primary btn-sm float-end" href="<?php echo e(route('admin.webinars.create')); ?>">افزودن وبینار</a>
<div class="row">
    <div class="col mb-3">
        <form action="<?php echo e(route('admin.webinars.index')); ?>" method="get">
            <div class="form-group">
                <div class="row">
                    <div class="col-9">
                        <input type="text" class="form-control" name="search" placeholder="جستجو">
                    </div>
                    <div class="col-2">
                        <button type="submit" class="btn btn-primary"> فیلتر</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
    <div class="row">
        <div class="col">
            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                    <thead>
                    <tr>
                        <th>ردیف</th>
                        <th>عنوان</th>
                        <th>سازنده</th>
                        <th>دسته بندی</th>
                        <th>قیمت</th>
                        <th>عکس</th>
                        <th>ویدئو</th>
                        <th>تاریخ انتشار</th>
                        <th>عملیات</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $webinars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $webinar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td> <?php echo e($loop->index + 1); ?></td>
                            <td> <?php echo e($webinar->title); ?></td>
                            <td> <?php echo e($webinar->user->name); ?></td>
                            <td> <?php echo e($webinar->category->name); ?></td>
                            <td> <?php echo e($webinar->price); ?></td>
                            <td style="text-align: center"> <img src="<?php echo e(env('APP_URL').'/storage/images/'.$webinar->img); ?>" width="200px" height="100px" /></td>
                            <td> <a href="<?php echo e(route('admin.webinars.download',$webinar->video)); ?>" class="btn btn-sm btn-primary">لینک دانلود</a></td>
                            <td> <?php echo e(jdate($webinar->created_at)->format('Y-m-d')); ?></td>
                            <td>
                                <form id="form-<?php echo e($webinar->id); ?>-delete" action="<?php echo e(route('admin.webinars.destroy', $webinar->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                </form>
                                <a href="#" onclick="event.preventDefault();askForDelete(<?php echo e($webinar->id); ?>)" class="btn btn-sm btn-danger">حذف</a>
                                <a href="<?php echo e(route('admin.webinars.edit',$webinar->id)); ?>" class="btn btn-sm btn-primary">ویرایش</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php echo e($webinars->appends(['search'=>request()->search])); ?>

        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        function askForDelete(id){
            Swal.fire({
                title: '',
                text: "آیا از حذف وبینار اطمینان دارید؟",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'بله',
                cancelButtonText: 'خیر' ,
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById(`form-${id}-delete`).submit();

                }
            })
        }


    </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\webinar\resources\views/admin/webinars/index.blade.php ENDPATH**/ ?>