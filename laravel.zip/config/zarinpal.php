<?php
return [
    'merchantId' => env('ZARINPAL_MERCHANTID'),
    'callback_url' => env('ZARINPAL_CALLBACK_URL')
];
